import { defineConfig, devices } from '@playwright/test';
import './src/utils/env';
import { AuthManager } from './src/auth/authManager';

const includeTag = process.env.TEST_TAG;
const excludeTag = process.env.EXCLUDE_TAG;

export default defineConfig({
  testDir: './tests',
  globalSetup: require.resolve('./src/auth/globalSetup'),
  fullyParallel: true,
  workers: 4,
  timeout: 60_000,
  expect: {
    timeout: 10_000
  },
  grep: includeTag ? new RegExp(includeTag) : undefined,
  grepInvert: excludeTag ? new RegExp(excludeTag) : undefined,
  reporter: [['html'], ['list']],
  use: {
    storageState: AuthManager.storageStatePath,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure'
  },
  projects: [
    {
      name: 'chrome',
      use: {
        ...devices['Desktop Chrome'],
        browserName: 'chromium',
        channel: 'chrome',
        viewport: null,
        launchOptions: {
          args: ['--start-maximized']
        }
      }
    }
  ]
});
