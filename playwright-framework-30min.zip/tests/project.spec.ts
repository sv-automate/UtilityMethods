import { test } from '../src/fixtures/testFixture';
import { getJsonTestDataById } from '../src/utils/testDataReader';

test.describe('Project Page Tests', () => {
  test('TC_PROJ_001 @smoke @project - Verify project details', async ({ projectPage }) => {
    const data = getJsonTestDataById<{
      projectName: string;
      expectedStatus: string;
    }>('projectData.json', 'TC_PROJ_001');

    await projectPage.open();
    await projectPage.verifyLoaded();
    await projectPage.verifyProjectName(data.projectName);
    await projectPage.verifyProjectStatus(data.expectedStatus);
  });
});
