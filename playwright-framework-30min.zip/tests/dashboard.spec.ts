import { test } from '../src/fixtures/testFixture';
import { getJsonTestDataById } from '../src/utils/testDataReader';

test.describe('Dashboard Page Tests', () => {
  test('TC_DASH_001 @smoke @dashboard - Verify dashboard page loads', async ({ dashboardPage }) => {
    getJsonTestDataById<{ expectedHeader: string }>('dashboardData.json', 'TC_DASH_001');

    await dashboardPage.open();
    await dashboardPage.verifyLoaded();
  });

  test('TC_DASH_002 @regression @dashboard @project - Navigate to project page', async ({
    dashboardPage,
    projectPage
  }) => {
    await dashboardPage.open();
    await dashboardPage.navigateToProject();
    await projectPage.verifyLoaded();
  });
});
