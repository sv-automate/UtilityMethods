import { test } from '../src/fixtures/testFixture';
import { getJsonTestDataById } from '../src/utils/testDataReader';

test.describe('Home Page Tests', () => {
  test('TC_HOME_001 @smoke @home - Verify home page loads', async ({ homePage }) => {
    getJsonTestDataById<{ expectedHeader: string }>('homeData.json', 'TC_HOME_001');

    await homePage.open();
    await homePage.verifyLoaded();
  });

  test('TC_HOME_002 @regression @home @dashboard - Navigate from home to dashboard', async ({
    homePage,
    dashboardPage
  }) => {
    await homePage.open();
    await homePage.navigateToDashboard();
    await dashboardPage.verifyLoaded();
  });
});
