import { test } from '../src/fixtures/testFixture';

test.describe('Help Page Tests', () => {
  test('TC_HELP_001 @smoke @help - Verify help page loads', async ({ helpPage }) => {
    await helpPage.open();
    await helpPage.verifyLoaded();
  });

  test('TC_HELP_002 @regression @help - Search help topic', async ({ helpPage }) => {
    await helpPage.open();
    await helpPage.searchHelp('project');
  });
});
