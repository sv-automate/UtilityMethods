import fs from 'fs';
import path from 'path';

const dataDir = path.resolve(process.cwd(), 'data');

export function getJsonTestDataById<T = any>(fileName: string, testCaseId: string): T {
  const filePath = path.join(dataDir, fileName);

  if (!fs.existsSync(filePath)) {
    throw new Error(`Test data file not found: ${filePath}`);
  }

  const records = JSON.parse(fs.readFileSync(filePath, 'utf-8')) as Array<{ testCaseId: string }>;
  const record = records.find((item) => item.testCaseId === testCaseId);

  if (!record) {
    throw new Error(`No test data found in ${fileName} for testCaseId: ${testCaseId}`);
  }

  return record as T;
}
