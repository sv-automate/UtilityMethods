import path from 'path';
import dotenv from 'dotenv';

const rootDir = process.cwd();
const configDir = path.resolve(rootDir, 'config');
const selectedEnv = process.env.TEST_ENV || 'qa';

dotenv.config({ path: path.join(configDir, '.env_common') });
dotenv.config({ path: path.join(configDir, `.env_${selectedEnv}`) });

const requiredEnvVars = ['BASE_URL', 'USERNAME', 'PASSWORD'];

for (const key of requiredEnvVars) {
  if (!process.env[key]) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
}

export const ENV = {
  TEST_ENV: selectedEnv,
  BASE_URL: process.env.BASE_URL!,
  USERNAME: process.env.USERNAME!,
  PASSWORD: process.env.PASSWORD!,
  SESSION_MAX_AGE_MINUTES: Number(process.env.SESSION_MAX_AGE_MINUTES || 30)
};
