import fs from 'fs';
import path from 'path';

const runtimeConfigPath = path.resolve(process.cwd(), '.auth/runtime-config.json');

export type RuntimeConfig = {
  homeUrl: string;
  dashboardUrl: string;
  createdAt: string;
};

export class RuntimeConfigManager {
  static runtimeConfigPath = runtimeConfigPath;

  static save(config: RuntimeConfig): void {
    fs.mkdirSync(path.dirname(runtimeConfigPath), { recursive: true });
    fs.writeFileSync(runtimeConfigPath, JSON.stringify(config, null, 2), 'utf-8');
  }

  static get(): RuntimeConfig {
    if (!fs.existsSync(runtimeConfigPath)) {
      throw new Error(`Runtime config not found at ${runtimeConfigPath}. globalSetup may not have completed successfully.`);
    }

    return JSON.parse(fs.readFileSync(runtimeConfigPath, 'utf-8')) as RuntimeConfig;
  }

  static getHomeUrl(): string {
    return this.get().homeUrl;
  }

  static getDashboardUrl(): string {
    return this.get().dashboardUrl;
  }

  static exists(): boolean {
    return fs.existsSync(runtimeConfigPath);
  }

  static remove(): void {
    if (fs.existsSync(runtimeConfigPath)) {
      fs.unlinkSync(runtimeConfigPath);
    }
  }
}
