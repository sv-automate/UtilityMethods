import { expect, Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { RuntimeConfigManager } from '../config/runtimeConfigManager';

export class ProjectPage extends BasePage {
  readonly projectHeader: Locator;
  readonly projectName: Locator;
  readonly projectStatus: Locator;

  constructor(page: Page) {
    super(page);
    this.projectHeader = page.getByRole('heading', { name: /project/i });
    this.projectName = page.locator('[data-testid="project-name"]');
    this.projectStatus = page.locator('[data-testid="project-status"]');
  }

  async open(): Promise<void> {
    await this.goto(`${RuntimeConfigManager.getDashboardUrl()}/project`);
  }

  async verifyLoaded(): Promise<void> {
    await expect(this.projectHeader).toBeVisible();
  }

  async verifyProjectName(expectedName: string): Promise<void> {
    await expect(this.projectName).toContainText(expectedName);
  }

  async verifyProjectStatus(expectedStatus: string): Promise<void> {
    await expect(this.projectStatus).toContainText(expectedStatus);
  }
}
