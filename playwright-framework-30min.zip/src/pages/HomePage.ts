import { expect, Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { RuntimeConfigManager } from '../config/runtimeConfigManager';

export class HomePage extends BasePage {
  readonly homeHeader: Locator;
  readonly dashboardButton: Locator;

  constructor(page: Page) {
    super(page);
    this.homeHeader = page.getByRole('heading', { name: /home/i });
    this.dashboardButton = page.getByRole('button', { name: /dashboard|open dashboard|continue/i });
  }

  async open(): Promise<void> {
    await this.goto(RuntimeConfigManager.getHomeUrl());
  }

  async verifyLoaded(): Promise<void> {
    await expect(this.homeHeader).toBeVisible();
  }

  async navigateToDashboardAndReturnUrl(): Promise<string> {
    await this.click(this.dashboardButton);
    await this.waitForPageReady();
    return this.page.url();
  }

  async navigateToDashboard(): Promise<void> {
    await this.click(this.dashboardButton);
    await this.waitForPageReady();
  }
}
