import { Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { ENV } from '../utils/env';

export class LoginPage extends BasePage {
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly acknowledgeCheckbox: Locator;

  constructor(page: Page) {
    super(page);
    this.usernameInput = page.getByLabel(/username|email/i);
    this.passwordInput = page.getByLabel(/password/i);
    this.loginButton = page.getByRole('button', { name: /login|sign in/i });
    this.acknowledgeCheckbox = page.getByRole('checkbox', { name: /acknowledge|agree|accept/i });
  }

  async open(): Promise<void> {
    await this.goto(ENV.BASE_URL);
  }

  async enterCredentials(): Promise<void> {
    await this.fill(this.usernameInput, ENV.USERNAME);
    await this.fill(this.passwordInput, ENV.PASSWORD);
  }

  async submitLogin(): Promise<void> {
    await this.click(this.loginButton);
    await this.waitForPageReady();
  }

  async acknowledgeIfDisplayed(): Promise<void> {
    const isVisible = await this.acknowledgeCheckbox.isVisible().catch(() => false);
    if (isVisible) {
      await this.check(this.acknowledgeCheckbox);
      await this.waitForPageReady();
    }
  }

  async loginAndNavigateToHome(): Promise<string> {
    await this.open();
    await this.enterCredentials();
    await this.submitLogin();
    await this.acknowledgeIfDisplayed();
    await this.waitForPageReady();
    return this.page.url();
  }
}
