import { expect, Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { RuntimeConfigManager } from '../config/runtimeConfigManager';

export class HelpPage extends BasePage {
  readonly helpHeader: Locator;
  readonly searchInput: Locator;

  constructor(page: Page) {
    super(page);
    this.helpHeader = page.getByRole('heading', { name: /help/i });
    this.searchInput = page.getByPlaceholder(/search/i);
  }

  async open(): Promise<void> {
    await this.goto(`${RuntimeConfigManager.getDashboardUrl()}/help`);
  }

  async verifyLoaded(): Promise<void> {
    await expect(this.helpHeader).toBeVisible();
  }

  async searchHelp(keyword: string): Promise<void> {
    await this.fill(this.searchInput, keyword);
    await this.page.keyboard.press('Enter');
    await this.waitForPageReady();
  }
}
