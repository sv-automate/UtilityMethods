import { expect, Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { RuntimeConfigManager } from '../config/runtimeConfigManager';

export class DashboardPage extends BasePage {
  readonly dashboardHeader: Locator;
  readonly helpLink: Locator;
  readonly projectLink: Locator;

  constructor(page: Page) {
    super(page);
    this.dashboardHeader = page.getByRole('heading', { name: /dashboard/i });
    this.helpLink = page.getByRole('link', { name: /help/i });
    this.projectLink = page.getByRole('link', { name: /project/i });
  }

  async open(): Promise<void> {
    await this.goto(RuntimeConfigManager.getDashboardUrl());
  }

  async verifyLoaded(): Promise<void> {
    await expect(this.dashboardHeader).toBeVisible();
  }

  async navigateToHelp(): Promise<void> {
    await this.click(this.helpLink);
    await this.waitForPageReady();
  }

  async navigateToProject(): Promise<void> {
    await this.click(this.projectLink);
    await this.waitForPageReady();
  }
}
