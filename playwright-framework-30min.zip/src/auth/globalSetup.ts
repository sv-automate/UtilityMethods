import { chromium } from '@playwright/test';
import { AuthManager } from './authManager';

async function globalSetup(): Promise<void> {
  const browser = await chromium.launch({
    channel: 'chrome',
    headless: true
  });

  try {
    if (AuthManager.isSessionExpiredByTime()) {
      await AuthManager.loginAndSaveState(browser);
    }
  } finally {
    await browser.close();
  }
}

export default globalSetup;
