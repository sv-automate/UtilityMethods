import fs from 'fs';
import path from 'path';
import { Browser } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { HomePage } from '../pages/HomePage';
import { RuntimeConfigManager } from '../config/runtimeConfigManager';
import { ENV } from '../utils/env';

const authDir = path.resolve(process.cwd(), '.auth');
const storageStatePath = path.join(authDir, 'user.json');
const authMetadataPath = path.join(authDir, 'auth-metadata.json');
const authLockPath = path.join(authDir, 'auth.lock');

type AuthMetadata = {
  createdAt: string;
};

export class AuthManager {
  static authDir = authDir;
  static storageStatePath = storageStatePath;
  static authMetadataPath = authMetadataPath;
  static authLockPath = authLockPath;

  static ensureAuthDir(): void {
    fs.mkdirSync(authDir, { recursive: true });
  }

  static isStorageStateAvailable(): boolean {
    return fs.existsSync(storageStatePath) && fs.existsSync(authMetadataPath) && RuntimeConfigManager.exists();
  }

  static isSessionExpiredByTime(): boolean {
    if (!this.isStorageStateAvailable()) {
      return true;
    }

    const metadata = JSON.parse(fs.readFileSync(authMetadataPath, 'utf-8')) as AuthMetadata;
    const createdAt = new Date(metadata.createdAt).getTime();
    const currentTime = Date.now();
    const ageInMinutes = (currentTime - createdAt) / 1000 / 60;

    return ageInMinutes >= ENV.SESSION_MAX_AGE_MINUTES;
  }

  static async loginAndSaveState(browser: Browser): Promise<void> {
    this.ensureAuthDir();

    const context = await browser.newContext({ viewport: null });
    const page = await context.newPage();

    const loginPage = new LoginPage(page);
    const homePage = new HomePage(page);

    const homeUrl = await loginPage.loginAndNavigateToHome();
    const dashboardUrl = await homePage.navigateToDashboardAndReturnUrl();

    await context.storageState({ path: storageStatePath });

    RuntimeConfigManager.save({
      homeUrl,
      dashboardUrl,
      createdAt: new Date().toISOString()
    });

    fs.writeFileSync(
      authMetadataPath,
      JSON.stringify({ createdAt: new Date().toISOString() }, null, 2),
      'utf-8'
    );

    await context.close();
  }

  static async reAuthenticate(browser: Browser): Promise<void> {
    await this.withAuthLock(async () => {
      await this.loginAndSaveState(browser);
    });
  }

  private static async withAuthLock(action: () => Promise<void>): Promise<void> {
    this.ensureAuthDir();

    const lockTimeoutMs = 120_000;
    const pollIntervalMs = 1000;
    const startTime = Date.now();

    while (fs.existsSync(authLockPath)) {
      if (Date.now() - startTime > lockTimeoutMs) {
        throw new Error('Timed out waiting for authentication lock.');
      }
      await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
    }

    fs.writeFileSync(authLockPath, String(process.pid), 'utf-8');

    try {
      await action();
    } finally {
      if (fs.existsSync(authLockPath)) {
        fs.unlinkSync(authLockPath);
      }
    }
  }
}
