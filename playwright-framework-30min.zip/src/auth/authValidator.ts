import { expect, Page } from '@playwright/test';

export class AuthValidator {
  static async isLoginPageDisplayed(page: Page): Promise<boolean> {
    const loginButtonVisible = await page
      .getByRole('button', { name: /login|sign in/i })
      .isVisible()
      .catch(() => false);

    const usernameVisible = await page
      .getByLabel(/username|email/i)
      .isVisible()
      .catch(() => false);

    return loginButtonVisible || usernameVisible;
  }

  static async expectDashboardDisplayed(page: Page): Promise<void> {
    await expect(page.getByRole('heading', { name: /dashboard/i })).toBeVisible();
  }
}
