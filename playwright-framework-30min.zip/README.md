# Playwright TypeScript Framework

This framework uses Playwright with TypeScript, Page Object Model, fixtures, globalSetup authentication, dynamic runtime URLs, tag execution, and JSON test data.

## Authentication flow

1. `globalSetup` opens `BASE_URL`.
2. Login credentials are entered.
3. Acknowledge checkbox is handled.
4. Home URL is captured dynamically.
5. Dashboard button is clicked from Home page.
6. Dashboard URL is captured dynamically.
7. Auth storage is saved to `.auth/user.json`.
8. Runtime URLs are saved to `.auth/runtime-config.json`.
9. Tests reuse the saved session and runtime URLs.
10. If the session expires during execution, the fixture re-authenticates and creates a fresh context.

## Session duration

Session age is set in:

```env
config/.env_common
SESSION_MAX_AGE_MINUTES=30
```

The framework checks this in `AuthManager.isSessionExpiredByTime()` before execution. During execution, the fixture validates the actual Dashboard URL and re-authenticates if redirected to the login page.

## Setup

```bash
npm install
npx playwright install chrome
```

## Run tests

```bash
npm run test:qa
npm run test:smoke
npm run test:dashboard
npm run test:project
```

## Environment files

Static config lives under `config/`:

```text
config/.env_common
config/.env_qa
config/.env_int
```

Dynamic runtime values live under `.auth/` and should not be committed.
