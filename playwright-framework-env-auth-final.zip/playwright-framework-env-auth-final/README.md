# Playwright TypeScript Framework

This framework uses globalSetup authentication and stores authentication/runtime state per environment.

## Auth storage

```text
.auth/
├── qa/
│   ├── user.json
│   ├── auth-metadata.json
│   └── runtime-config.json
├── int/
└── unit/
```

## Runtime URLs

After login, the framework captures:

- homeUrl
- dashboardUrl

These are saved in `.auth/<TEST_ENV>/runtime-config.json`.

## Run

```bash
npm install
npx playwright install chrome
npm run test:qa
npm run test:int
npm run test:unit
```

## Tags

```bash
npm run test:smoke
npm run test:dashboard
npm run test:project
```

## Changed files for per-environment auth

```text
src/auth/authManager.ts
src/config/runtimeConfigManager.ts
src/utils/env.ts
playwright.config.ts
package.json
.gitignore
config/.env_unit.example
config/.env_unit
README.md
```
