import fs from 'fs';
import path from 'path';
import { Browser } from '@playwright/test';
import { ENV } from '../utils/env';
import { LoginPage } from '../pages/LoginPage';
import { HomePage } from '../pages/HomePage';
import { RuntimeConfigManager } from '../config/runtimeConfigManager';

type AuthMetadata = {
  createdAt: string;
  env: string;
};

export class AuthManager {
  static get authDir(): string {
    return path.resolve(process.cwd(), '.auth', ENV.TEST_ENV);
  }

  static get storageStatePath(): string {
    return path.join(this.authDir, 'user.json');
  }

  static get authMetadataPath(): string {
    return path.join(this.authDir, 'auth-metadata.json');
  }

  static get authLockPath(): string {
    return path.join(this.authDir, 'auth.lock');
  }

  static ensureAuthDir(): void {
    fs.mkdirSync(this.authDir, { recursive: true });
  }

  static isStorageStateAvailable(): boolean {
    return (
      fs.existsSync(this.storageStatePath) &&
      fs.existsSync(this.authMetadataPath) &&
      RuntimeConfigManager.exists()
    );
  }

  static isSessionExpiredByTime(): boolean {
    if (!this.isStorageStateAvailable()) {
      return true;
    }

    const metadata: AuthMetadata = JSON.parse(
      fs.readFileSync(this.authMetadataPath, 'utf-8')
    );

    const createdAt = new Date(metadata.createdAt).getTime();
    const currentTime = Date.now();
    const ageInMinutes = (currentTime - createdAt) / 1000 / 60;

    return ageInMinutes >= ENV.SESSION_MAX_AGE_MINUTES;
  }

  static async loginAndSaveState(browser: Browser): Promise<void> {
    this.ensureAuthDir();

    const context = await browser.newContext({ viewport: null });
    const page = await context.newPage();

    const loginPage = new LoginPage(page);
    const homePage = new HomePage(page);

    const homeUrl = await loginPage.loginAndNavigateToHome();
    const dashboardUrl = await homePage.navigateToDashboardAndReturnUrl();

    await context.storageState({ path: this.storageStatePath });

    RuntimeConfigManager.save({
      homeUrl,
      dashboardUrl,
      createdAt: new Date().toISOString()
    });

    fs.writeFileSync(
      this.authMetadataPath,
      JSON.stringify(
        {
          createdAt: new Date().toISOString(),
          env: ENV.TEST_ENV
        },
        null,
        2
      ),
      'utf-8'
    );

    await context.close();
  }

  static async reAuthenticate(browser: Browser): Promise<void> {
    await this.withAuthLock(async () => {
      await this.loginAndSaveState(browser);
    });
  }

  private static async withAuthLock(action: () => Promise<void>): Promise<void> {
    this.ensureAuthDir();

    const lockTimeoutMs = 120_000;
    const pollIntervalMs = 1000;
    const startTime = Date.now();

    while (fs.existsSync(this.authLockPath)) {
      if (Date.now() - startTime > lockTimeoutMs) {
        throw new Error('Timed out waiting for authentication lock.');
      }

      await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
    }

    fs.writeFileSync(this.authLockPath, String(process.pid), 'utf-8');

    try {
      await action();
    } finally {
      if (fs.existsSync(this.authLockPath)) {
        fs.unlinkSync(this.authLockPath);
      }
    }
  }
}
