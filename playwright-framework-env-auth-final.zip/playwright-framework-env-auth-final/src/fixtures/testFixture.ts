import { Browser, BrowserContext, Page, test as base } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { HomePage } from '../pages/HomePage';
import { DashboardPage } from '../pages/DashboardPage';
import { HelpPage } from '../pages/HelpPage';
import { ProjectPage } from '../pages/ProjectPage';
import { AuthManager } from '../auth/authManager';
import { AuthValidator } from '../auth/authValidator';
import { RuntimeConfigManager } from '../config/runtimeConfigManager';

export type AppFixtures = {
  authenticatedPage: Page;
  loginPage: LoginPage;
  homePage: HomePage;
  dashboardPage: DashboardPage;
  helpPage: HelpPage;
  projectPage: ProjectPage;
};

async function createAuthenticatedPage(browser: Browser): Promise<{
  context: BrowserContext;
  page: Page;
}> {
  const context = await browser.newContext({
    storageState: AuthManager.storageStatePath,
    viewport: null
  });

  const page = await context.newPage();
  return { context, page };
}

export const test = base.extend<AppFixtures>({
  authenticatedPage: async ({ browser }, use) => {
    let { context, page } = await createAuthenticatedPage(browser);

    await page.goto(RuntimeConfigManager.getDashboardUrl(), {
      waitUntil: 'domcontentloaded'
    });

    const loginDisplayed = await AuthValidator.isLoginPageDisplayed(page);

    if (loginDisplayed) {
      await context.close();
      await AuthManager.reAuthenticate(browser);

      const freshSession = await createAuthenticatedPage(browser);
      context = freshSession.context;
      page = freshSession.page;

      await page.goto(RuntimeConfigManager.getDashboardUrl(), {
        waitUntil: 'domcontentloaded'
      });

      await AuthValidator.expectDashboardDisplayed(page);
    }

    await use(page);
    await context.close();
  },

  loginPage: async ({ authenticatedPage }, use) => {
    await use(new LoginPage(authenticatedPage));
  },

  homePage: async ({ authenticatedPage }, use) => {
    await use(new HomePage(authenticatedPage));
  },

  dashboardPage: async ({ authenticatedPage }, use) => {
    await use(new DashboardPage(authenticatedPage));
  },

  helpPage: async ({ authenticatedPage }, use) => {
    await use(new HelpPage(authenticatedPage));
  },

  projectPage: async ({ authenticatedPage }, use) => {
    await use(new ProjectPage(authenticatedPage));
  }
});

export { expect } from '@playwright/test';
