import fs from 'fs';
import path from 'path';
import { ENV } from '../utils/env';

export type RuntimeConfig = {
  homeUrl: string;
  dashboardUrl: string;
  createdAt: string;
};

export class RuntimeConfigManager {
  static get runtimeConfigPath(): string {
    return path.resolve(
      process.cwd(),
      '.auth',
      ENV.TEST_ENV,
      'runtime-config.json'
    );
  }

  static save(config: RuntimeConfig): void {
    fs.mkdirSync(path.dirname(this.runtimeConfigPath), { recursive: true });
    fs.writeFileSync(this.runtimeConfigPath, JSON.stringify(config, null, 2), 'utf-8');
  }

  static get(): RuntimeConfig {
    if (!fs.existsSync(this.runtimeConfigPath)) {
      throw new Error(`Runtime config not found: ${this.runtimeConfigPath}`);
    }

    return JSON.parse(fs.readFileSync(this.runtimeConfigPath, 'utf-8'));
  }

  static getHomeUrl(): string {
    return this.get().homeUrl;
  }

  static getDashboardUrl(): string {
    return this.get().dashboardUrl;
  }

  static exists(): boolean {
    return fs.existsSync(this.runtimeConfigPath);
  }
}
