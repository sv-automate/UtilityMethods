# Playwright TypeScript Framework - globalSetup Auth

This framework uses Playwright with TypeScript, Page Object Model, custom fixtures, tag-based execution, JSON/CSV test data, and `globalSetup` authentication.

## Flow

```text
BASE_URL login page
  -> enter username/password
  -> acknowledge checkbox
  -> switch user if required
  -> navigate to PROJECT_URL main project
  -> save authenticated browser context to .auth/user.json
  -> execute Dashboard, Help, and Project tests using stored context
```

## Structure

```text
config/
  .env_common.example
  .env_qa.example
  .env_int.example
data/
  dashboardData.json
  helpData.json
  projectData.json
  projectData.csv
src/
  auth/
    globalSetup.ts
    authManager.ts
    authValidator.ts
  fixtures/
    testFixture.ts
  pages/
    BasePage.ts
    LoginPage.ts
    DashboardPage.ts
    HelpPage.ts
    ProjectPage.ts
  utils/
    env.ts
    testDataReader.ts
    urlBuilder.ts
tests/
  dashboard.spec.ts
  help.spec.ts
  project.spec.ts
playwright.config.ts
package.json
```

## Environment setup

Copy examples and update real values:

```bash
cp config/.env_common.example config/.env_common
cp config/.env_qa.example config/.env_qa
cp config/.env_int.example config/.env_int
```

Example:

```env
BASE_URL=https://qa-login.example.com
PROJECT_URL=https://qa-main-project.example.com
USERNAME=qa_user
PASSWORD=qa_password
SESSION_MAX_AGE_MINUTES=20
DASHBOARD_PATH=/dashboard
HELP_PATH=/help
PROJECT_PATH=/project
```

## Install

```bash
npm install
npx playwright install chrome
```

## Run

```bash
npm run test:qa
npm run test:int
npm run test:smoke
npm run test:regression
npm run test:dashboard
npm run test:help
npm run test:project
```

Tag filtering is controlled through `TEST_TAG` and `EXCLUDE_TAG`.

```bash
TEST_TAG=@smoke npm test
EXCLUDE_TAG=@wip npm test
```

## Authentication design

`globalSetup.ts` runs before test execution. It checks if `.auth/user.json` exists and if the session age is still valid. It also opens the dashboard URL to confirm that the stored session is truly logged in.

If the session is invalid, it logs in again and saves a new storage state.

During test execution, `testFixture.ts` also checks whether the app redirected to login. If yes, it re-authenticates and continues.

## Fixtures

Tests import from:

```ts
import { test, expect } from '../src/fixtures/testFixture';
```

Available fixtures:

```text
authenticatedPage
loginPage
dashboardPage
helpPage
projectPage
```

## Best practices

- Prefer `data-testid`, role, label, and text locators.
- Avoid XPath unless there is no stable alternative.
- Do not use hard waits.
- Keep page objects focused on page actions and validations.
- Keep test assertions in specs or page verification methods.
- Keep tests independent and parallel-safe.
- Use unique test data for create/update/delete tests.
- Do not commit `.env` or `.auth` files.
- Store secrets in CI secret variables.
- Use tags such as `@smoke`, `@regression`, `@dashboard`, `@help`, and `@project`.
- Keep trace, screenshot, and video enabled for failures.
- Use API setup/cleanup when possible.
