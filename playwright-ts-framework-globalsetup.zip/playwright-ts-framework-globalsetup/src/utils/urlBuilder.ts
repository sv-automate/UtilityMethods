import { ENV } from './env';

function joinUrl(baseUrl: string, pathValue: string): string {
  const normalizedBase = baseUrl.replace(/\/+$/, '');
  const normalizedPath = pathValue.startsWith('/') ? pathValue : `/${pathValue}`;
  return `${normalizedBase}${normalizedPath}`;
}

export const UrlBuilder = {
  loginUrl(): string {
    return ENV.BASE_URL;
  },

  mainProjectUrl(): string {
    return ENV.PROJECT_URL;
  },

  dashboardUrl(): string {
    return joinUrl(ENV.PROJECT_URL, ENV.DASHBOARD_PATH);
  },

  helpUrl(): string {
    return joinUrl(ENV.PROJECT_URL, ENV.HELP_PATH);
  },

  projectUrl(): string {
    return joinUrl(ENV.PROJECT_URL, ENV.PROJECT_PATH);
  }
};
