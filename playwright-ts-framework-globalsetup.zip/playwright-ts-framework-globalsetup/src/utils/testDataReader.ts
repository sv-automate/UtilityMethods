import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';

const dataDir = path.resolve(process.cwd(), 'data');
const jsonCache = new Map<string, unknown[]>();
const csvCache = new Map<string, Record<string, string>[]>();

function getFilePath(fileName: string): string {
  const filePath = path.join(dataDir, fileName);

  if (!fs.existsSync(filePath)) {
    throw new Error(`Test data file not found: ${filePath}`);
  }

  return filePath;
}

function readJson(fileName: string): unknown[] {
  if (jsonCache.has(fileName)) {
    return jsonCache.get(fileName)!;
  }

  const filePath = getFilePath(fileName);
  const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

  if (!Array.isArray(data)) {
    throw new Error(`JSON test data should be an array: ${fileName}`);
  }

  jsonCache.set(fileName, data);
  return data;
}

function readCsv(fileName: string): Record<string, string>[] {
  if (csvCache.has(fileName)) {
    return csvCache.get(fileName)!;
  }

  const filePath = getFilePath(fileName);
  const records = parse(fs.readFileSync(filePath, 'utf-8'), {
    columns: true,
    skip_empty_lines: true,
    trim: true
  });

  csvCache.set(fileName, records);
  return records;
}

export function getTestDataById<T = any>(fileName: string, testCaseId: string): T {
  const records = fileName.endsWith('.json')
    ? readJson(fileName)
    : fileName.endsWith('.csv')
      ? readCsv(fileName)
      : undefined;

  if (!records) {
    throw new Error(`Unsupported test data file type: ${fileName}`);
  }

  const record = records.find((item: any) => item.testCaseId === testCaseId);

  if (!record) {
    throw new Error(`No test data found in ${fileName} for testCaseId: ${testCaseId}`);
  }

  return record as T;
}
