import path from 'path';
import dotenv from 'dotenv';

const rootDir = process.cwd();
const configDir = path.resolve(rootDir, 'config');
const selectedEnv = process.env.TEST_ENV || 'qa';

function loadEnvFile(fileName: string, required = true): void {
  const envPath = path.join(configDir, fileName);
  const result = dotenv.config({ path: envPath, override: false });

  if (required && result.error) {
    throw new Error(`Unable to load environment file: ${envPath}`);
  }
}

loadEnvFile('.env_common');
loadEnvFile(`.env_${selectedEnv}`);

const requiredEnvVars = ['BASE_URL', 'PROJECT_URL', 'USERNAME', 'PASSWORD'];

for (const envKey of requiredEnvVars) {
  if (!process.env[envKey]) {
    throw new Error(`Missing required environment variable: ${envKey}`);
  }
}

export const ENV = {
  TEST_ENV: selectedEnv,
  BASE_URL: process.env.BASE_URL!,
  PROJECT_URL: process.env.PROJECT_URL!,
  USERNAME: process.env.USERNAME!,
  PASSWORD: process.env.PASSWORD!,
  SESSION_MAX_AGE_MINUTES: Number(process.env.SESSION_MAX_AGE_MINUTES || 20),
  DASHBOARD_PATH: process.env.DASHBOARD_PATH || '/dashboard',
  HELP_PATH: process.env.HELP_PATH || '/help',
  PROJECT_PATH: process.env.PROJECT_PATH || '/project'
};
