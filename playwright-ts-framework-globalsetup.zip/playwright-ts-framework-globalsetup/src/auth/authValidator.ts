import fs from 'fs';
import { Page } from '@playwright/test';
import { ENV } from '../utils/env';
import { UrlBuilder } from '../utils/urlBuilder';
import { AuthManager } from './authManager';

export class AuthValidator {
  static hasStorageState(): boolean {
    return fs.existsSync(AuthManager.STORAGE_STATE_PATH);
  }

  static isSessionAgeValid(): boolean {
    if (!fs.existsSync(AuthManager.AUTH_METADATA_PATH)) {
      return false;
    }

    const metadata = JSON.parse(fs.readFileSync(AuthManager.AUTH_METADATA_PATH, 'utf-8')) as {
      createdAt: string;
    };

    const createdAt = new Date(metadata.createdAt).getTime();
    const ageInMinutes = (Date.now() - createdAt) / 1000 / 60;

    return ageInMinutes < ENV.SESSION_MAX_AGE_MINUTES;
  }

  static async isLoginPageDisplayed(page: Page): Promise<boolean> {
    const loginButtonVisible = await page
      .getByRole('button', { name: /login|log in|sign in/i })
      .isVisible({ timeout: 5_000 })
      .catch(() => false);

    const usernameVisible = await page
      .getByLabel(/username|email|user id/i)
      .isVisible({ timeout: 5_000 })
      .catch(() => false);

    return loginButtonVisible || usernameVisible;
  }

  static async isProjectSessionValid(page: Page): Promise<boolean> {
    await page.goto(UrlBuilder.dashboardUrl(), { waitUntil: 'domcontentloaded' });

    if (await this.isLoginPageDisplayed(page)) {
      return false;
    }

    const dashboardVisible = await page
      .getByRole('heading', { name: /dashboard/i })
      .isVisible({ timeout: 10_000 })
      .catch(() => false);

    const userMenuVisible = await page
      .locator('[data-testid="user-menu"]')
      .isVisible({ timeout: 5_000 })
      .catch(() => false);

    return dashboardVisible || userMenuVisible || page.url().startsWith(ENV.PROJECT_URL);
  }
}
