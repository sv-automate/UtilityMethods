import fs from 'fs';
import path from 'path';
import { Browser, Page } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { AuthValidator } from './authValidator';

const authDir = path.resolve(process.cwd(), '.auth');

export class AuthManager {
  static readonly AUTH_DIR = authDir;
  static readonly STORAGE_STATE_PATH = path.join(authDir, 'user.json');
  static readonly AUTH_METADATA_PATH = path.join(authDir, 'metadata.json');

  static ensureAuthDirectory(): void {
    fs.mkdirSync(this.AUTH_DIR, { recursive: true });
  }

  static async initialize(browser: Browser): Promise<void> {
    this.ensureAuthDirectory();

    if (AuthValidator.hasStorageState() && AuthValidator.isSessionAgeValid()) {
      const context = await browser.newContext({ storageState: this.STORAGE_STATE_PATH });
      const page = await context.newPage();
      const isValid = await AuthValidator.isProjectSessionValid(page);
      await context.close();

      if (isValid) {
        console.log('AuthManager: using existing authenticated storage state.');
        return;
      }
    }

    console.log('AuthManager: creating a new authenticated storage state.');
    await this.loginAndSaveStorage(browser);
  }

  static async loginAndSaveStorage(browser: Browser): Promise<void> {
    this.ensureAuthDirectory();

    const context = await browser.newContext();
    const page = await context.newPage();

    await this.loginWithPage(page);

    await context.storageState({ path: this.STORAGE_STATE_PATH });

    fs.writeFileSync(
      this.AUTH_METADATA_PATH,
      JSON.stringify(
        {
          createdAt: new Date().toISOString()
        },
        null,
        2
      )
    );

    await context.close();
  }

  static async loginWithPage(page: Page): Promise<void> {
    const loginPage = new LoginPage(page);
    await loginPage.completeLoginFlow();
  }

  static async reAuthenticate(browser: Browser): Promise<void> {
    console.log('AuthManager: session expired during execution. Re-authenticating.');
    await this.loginAndSaveStorage(browser);
  }
}
