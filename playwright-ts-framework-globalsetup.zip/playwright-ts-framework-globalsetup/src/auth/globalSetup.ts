import { chromium, FullConfig } from '@playwright/test';
import '../utils/env';
import { AuthManager } from './authManager';

async function globalSetup(_config: FullConfig): Promise<void> {
  const browser = await chromium.launch({
    channel: 'chrome',
    headless: true
  });

  try {
    await AuthManager.initialize(browser);
  } finally {
    await browser.close();
  }
}

export default globalSetup;
