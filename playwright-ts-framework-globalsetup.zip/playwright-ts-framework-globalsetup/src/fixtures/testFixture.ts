import { test as base, Page } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { HelpPage } from '../pages/HelpPage';
import { ProjectPage } from '../pages/ProjectPage';
import { AuthManager } from '../auth/authManager';
import { AuthValidator } from '../auth/authValidator';
import { UrlBuilder } from '../utils/urlBuilder';

export type AppFixtures = {
  authenticatedPage: Page;
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
  helpPage: HelpPage;
  projectPage: ProjectPage;
};

export const test = base.extend<AppFixtures>({
  authenticatedPage: async ({ page, browser }, use) => {
    await page.goto(UrlBuilder.dashboardUrl(), { waitUntil: 'domcontentloaded' });

    if (await AuthValidator.isLoginPageDisplayed(page)) {
      await AuthManager.reAuthenticate(browser);
      await page.context().clearCookies();
      await page.goto(UrlBuilder.dashboardUrl(), { waitUntil: 'domcontentloaded' });
    }

    await use(page);
  },

  loginPage: async ({ authenticatedPage }, use) => {
    await use(new LoginPage(authenticatedPage));
  },

  dashboardPage: async ({ authenticatedPage }, use) => {
    await use(new DashboardPage(authenticatedPage));
  },

  helpPage: async ({ authenticatedPage }, use) => {
    await use(new HelpPage(authenticatedPage));
  },

  projectPage: async ({ authenticatedPage }, use) => {
    await use(new ProjectPage(authenticatedPage));
  }
});

export { expect } from '@playwright/test';
