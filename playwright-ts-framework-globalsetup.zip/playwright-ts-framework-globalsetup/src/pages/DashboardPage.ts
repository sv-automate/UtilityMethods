import { Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { UrlBuilder } from '../utils/urlBuilder';

export class DashboardPage extends BasePage {
  readonly dashboardHeader: Locator;
  readonly helpLink: Locator;
  readonly projectLink: Locator;
  readonly userMenu: Locator;

  constructor(page: Page) {
    super(page);
    this.dashboardHeader = page.getByRole('heading', { name: /dashboard/i });
    this.helpLink = page.getByRole('link', { name: /help/i });
    this.projectLink = page.getByRole('link', { name: /project/i });
    this.userMenu = page.locator('[data-testid="user-menu"]');
  }

  async open(): Promise<void> {
    await this.goto(UrlBuilder.dashboardUrl());
  }

  async verifyLoaded(): Promise<void> {
    await this.verifyVisible(this.dashboardHeader);
  }

  async navigateToHelp(): Promise<void> {
    await this.click(this.helpLink);
  }

  async navigateToProject(): Promise<void> {
    await this.click(this.projectLink);
  }
}
