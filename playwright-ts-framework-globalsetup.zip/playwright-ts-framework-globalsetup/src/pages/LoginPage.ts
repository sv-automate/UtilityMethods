import { Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { ENV } from '../utils/env';
import { UrlBuilder } from '../utils/urlBuilder';

export class LoginPage extends BasePage {
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly acknowledgeCheckbox: Locator;
  readonly loginButton: Locator;
  readonly switchUserButton: Locator;
  readonly mainProjectLink: Locator;

  constructor(page: Page) {
    super(page);

    this.usernameInput = page.getByLabel(/username|email|user id/i);
    this.passwordInput = page.getByLabel(/password/i);
    this.acknowledgeCheckbox = page.getByRole('checkbox', { name: /acknowledge|agree|accept/i });
    this.loginButton = page.getByRole('button', { name: /login|log in|sign in/i });
    this.switchUserButton = page.getByRole('button', { name: /switch user|continue as|select user/i });
    this.mainProjectLink = page.getByRole('link', { name: /main project|project/i });
  }

  async open(): Promise<void> {
    await this.goto(UrlBuilder.loginUrl());
  }

  async enterCredentials(username = ENV.USERNAME, password = ENV.PASSWORD): Promise<void> {
    await this.fill(this.usernameInput, username);
    await this.fill(this.passwordInput, password);
  }

  async acknowledgeIfVisible(): Promise<void> {
    if (await this.acknowledgeCheckbox.isVisible().catch(() => false)) {
      await this.check(this.acknowledgeCheckbox);
    }
  }

  async submitLogin(): Promise<void> {
    await this.click(this.loginButton);
    await this.waitForPageReady();
  }

  async switchUserIfRequired(): Promise<void> {
    if (await this.switchUserButton.isVisible({ timeout: 10_000 }).catch(() => false)) {
      await this.click(this.switchUserButton);
      await this.waitForPageReady();
    }
  }

  async navigateToMainProject(): Promise<void> {
    if (await this.mainProjectLink.isVisible({ timeout: 10_000 }).catch(() => false)) {
      await this.click(this.mainProjectLink);
      await this.waitForPageReady();
      return;
    }

    await this.goto(UrlBuilder.mainProjectUrl());
  }

  async completeLoginFlow(): Promise<void> {
    await this.open();
    await this.enterCredentials();
    await this.acknowledgeIfVisible();
    await this.submitLogin();
    await this.switchUserIfRequired();
    await this.navigateToMainProject();
  }
}
