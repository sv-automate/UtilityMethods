import { Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { UrlBuilder } from '../utils/urlBuilder';

export class HelpPage extends BasePage {
  readonly helpHeader: Locator;
  readonly searchInput: Locator;
  readonly searchResults: Locator;

  constructor(page: Page) {
    super(page);
    this.helpHeader = page.getByRole('heading', { name: /help/i });
    this.searchInput = page.getByPlaceholder(/search/i);
    this.searchResults = page.locator('[data-testid="help-search-results"]');
  }

  async open(): Promise<void> {
    await this.goto(UrlBuilder.helpUrl());
  }

  async verifyLoaded(): Promise<void> {
    await this.verifyVisible(this.helpHeader);
  }

  async searchHelp(keyword: string): Promise<void> {
    await this.fill(this.searchInput, keyword);
    await this.page.keyboard.press('Enter');
  }
}
