import { Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { UrlBuilder } from '../utils/urlBuilder';

export class ProjectPage extends BasePage {
  readonly projectHeader: Locator;
  readonly projectName: Locator;
  readonly projectStatus: Locator;

  constructor(page: Page) {
    super(page);
    this.projectHeader = page.getByRole('heading', { name: /project/i });
    this.projectName = page.locator('[data-testid="project-name"]');
    this.projectStatus = page.locator('[data-testid="project-status"]');
  }

  async open(): Promise<void> {
    await this.goto(UrlBuilder.projectUrl());
  }

  async verifyLoaded(): Promise<void> {
    await this.verifyVisible(this.projectHeader);
  }

  async verifyProjectName(expectedName: string): Promise<void> {
    await this.verifyText(this.projectName, expectedName);
  }

  async verifyProjectStatus(expectedStatus: string): Promise<void> {
    await this.verifyText(this.projectStatus, expectedStatus);
  }
}
