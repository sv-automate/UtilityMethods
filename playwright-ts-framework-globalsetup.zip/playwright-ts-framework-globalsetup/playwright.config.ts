import { defineConfig, devices } from '@playwright/test';
import './src/utils/env';
import { AuthManager } from './src/auth/authManager';

const includeTag = process.env.TEST_TAG;
const excludeTag = process.env.EXCLUDE_TAG;

export default defineConfig({
  testDir: './tests',
  globalSetup: require.resolve('./src/auth/globalSetup'),
  fullyParallel: true,
  workers: 4,
  timeout: 60_000,
  expect: {
    timeout: 10_000
  },
  grep: includeTag ? new RegExp(includeTag) : undefined,
  grepInvert: excludeTag ? new RegExp(excludeTag) : undefined,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    actionTimeout: 15_000,
    navigationTimeout: 30_000
  },
  projects: [
    {
      name: 'chrome',
      use: {
        ...devices['Desktop Chrome'],
        browserName: 'chromium',
        channel: 'chrome',
        viewport: null,
        storageState: AuthManager.STORAGE_STATE_PATH,
        launchOptions: {
          args: ['--start-maximized']
        }
      }
    }
  ]
});
