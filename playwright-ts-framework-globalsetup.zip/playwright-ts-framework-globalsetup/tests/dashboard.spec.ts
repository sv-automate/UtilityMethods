import { test } from '../src/fixtures/testFixture';
import { getTestDataById } from '../src/utils/testDataReader';

test.describe('Dashboard Page Tests', () => {
  test('TC_DASH_001 @smoke @dashboard - Verify dashboard page loads', async ({ dashboardPage }) => {
    getTestDataById('dashboardData.json', 'TC_DASH_001');

    await dashboardPage.open();
    await dashboardPage.verifyLoaded();
  });

  test('TC_DASH_002 @regression @dashboard - Navigate to project page from dashboard', async ({
    dashboardPage,
    projectPage
  }) => {
    getTestDataById('dashboardData.json', 'TC_DASH_002');

    await dashboardPage.open();
    await dashboardPage.navigateToProject();
    await projectPage.verifyLoaded();
  });
});
