import { test } from '../src/fixtures/testFixture';
import { getTestDataById } from '../src/utils/testDataReader';

type HelpData = {
  testCaseId: string;
  searchKeyword?: string;
};

test.describe('Help Page Tests', () => {
  test('TC_HELP_001 @smoke @help - Verify help page loads', async ({ helpPage }) => {
    getTestDataById('helpData.json', 'TC_HELP_001');

    await helpPage.open();
    await helpPage.verifyLoaded();
  });

  test('TC_HELP_002 @regression @help - Search help topic', async ({ helpPage }) => {
    const data = getTestDataById<HelpData>('helpData.json', 'TC_HELP_002');

    await helpPage.open();
    await helpPage.searchHelp(data.searchKeyword || 'project');
  });
});
