import { test } from '../src/fixtures/testFixture';
import { getTestDataById } from '../src/utils/testDataReader';

type ProjectData = {
  testCaseId: string;
  projectName: string;
  expectedStatus: string;
};

test.describe('Project Page Tests', () => {
  test('TC_PROJ_001 @smoke @project - Verify project details using JSON data', async ({ projectPage }) => {
    const data = getTestDataById<ProjectData>('projectData.json', 'TC_PROJ_001');

    await projectPage.open();
    await projectPage.verifyLoaded();
    await projectPage.verifyProjectName(data.projectName);
    await projectPage.verifyProjectStatus(data.expectedStatus);
  });

  test('TC_PROJ_002 @regression @project - Verify project details using CSV data', async ({ projectPage }) => {
    const data = getTestDataById<ProjectData>('projectData.csv', 'TC_PROJ_002');

    await projectPage.open();
    await projectPage.verifyLoaded();
    await projectPage.verifyProjectName(data.projectName);
    await projectPage.verifyProjectStatus(data.expectedStatus);
  });
});
